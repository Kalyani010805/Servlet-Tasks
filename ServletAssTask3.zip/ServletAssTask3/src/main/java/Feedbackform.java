

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class Feedbackform
 */
@WebServlet("/Feedbackform")
public class Feedbackform extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		out.print("<html>");
		out.print("<body>");
		out.print("<center>");
		out.print("<h1>FeedBack Form</h1>");
		out.print("<form action='FeedbackResponse'>");
		out.print("Enter name: <input type='text' name='name'>");
		out.print("<br/><br/>");
		out.print("Enter rating : <input type='number' name='rating'>");
		out.print("<br/><br/>");
		out.print("Comments : <input type='text' name='comments'>");
		out.print("<br/><br/>");
		out.print("<button type='submit'>Submit</button>");
		
		out.print("<form>");
		out.print("</center>");
		
		out.print("</body>");
		out.print("</html>");
		
		
		
	}

}
