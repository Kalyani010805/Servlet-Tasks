

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class LoginMsg
 */
@WebServlet("/LoginMsg")
public class LoginMsg extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	 response.setContentType("text/html");
	 PrintWriter out=response.getWriter();
	 
	 String name=request.getParameter("uname");
	 String password=request.getParameter("upass");
	 
	 if("admin".equals(name)&&"admin123".equals(password)) {
		 out.print("Successfully Login");
	 }
	 
	 else {
		 out.print("Invalid username or password , please try again");
	 }
	 
	}

}
