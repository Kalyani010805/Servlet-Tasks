
 //Task 2: Process login Credentials using Servlet

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class LoginInfo
 */
@WebServlet("/LoginInfo")
public class LoginInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    response.setContentType("text/html");
	    PrintWriter out=response.getWriter();
	    
	    out.print("<html>");
	    out.print("<body>");
	    out.print("<center>");
	    out.print("<h1>Login Page</h1>");
	    out.print("<hr/>");
	    out.print("<form action='LoginMsg'>");
	    
	    out.print("Enter username : <input type='text' name='uname'>");
	    out.print("<br/><br/>");
	    out.print("Enter password : <input type='text' name='upass'>");
	    out.print("<br/><br/>");
	    out.print("<button type='submit'>Login</button>");
	    
	    out.print("</form>");
	    out.print("</center>");
	    out.print("</body>");
	    out.print("</html>");
	    
	}

}
