

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Servlet implementation class ProductInsertion
 */
@WebServlet("/ProductInsertion")
public class ProductInsertion extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String id=request.getParameter("id");
		String name=request.getParameter("name");
		String price=request.getParameter("price");
		String quantity=request.getParameter("quantity");
		
		int p_id=Integer.parseInt(id);
		double p_price=Double.parseDouble(price);
		int p_quant=Integer.parseInt(quantity);
		
		//Connecting Servlet to database : to connect servlet with database we have to configure mysql connector jar file in 
		// case of mysql database 
		//how to configure and where to configure : Go to downloads -> copy mysql connector jar file -> paste it into following path as :
		// go to your projects src folder expand it -> main-> webapp->webinf-> lib , paste the jar file here in lib
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/productsdb","root","01082005");
			System.out.println("Connection Successful");
			PreparedStatement stmt=con.prepareStatement("Insert into productinfo values(?,?,?,?)");
			stmt.setInt(1, p_id);
			stmt.setString(2, name);
			stmt.setDouble(3, p_price);
			stmt.setInt(4, p_quant);
			
			int count=stmt.executeUpdate();
			System.out.println(count + "Rows Inserted Successfully");
			out.print("Data Inserted Successfully");
			out.print("<br/>");
			
			
			// Task 5: Retrival of Data
			
			/*
			 * PreparedStatement stmt1=con.prepareStatement("Select * from productinfo");
			 * ResultSet rs=stmt1.executeQuery();
			 * out.print("<tc>ID  NAME  PRICE  QUANTITY</tc>"); out.print("<br/>");
			 * 
			 * while(rs.next()) { out.print(rs.getInt("id"));
			 * out.print(rs.getString("name")); out.print(rs.getDouble("price"));
			 * out.print(rs.getInt("quantity"));
			 * 
			 * 
			 * }
			 */
			con.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}

}
