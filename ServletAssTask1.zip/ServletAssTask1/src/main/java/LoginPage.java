
// Task 1: Create and display login page using servlet

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class LoginPage
 */
@WebServlet("/LoginPage")
public class LoginPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	      response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.print("<html>");
	    out.print("<body>");
		out.print("<center>");
		out.print("<h1>Login Page</h1>");
		out.print("<hr/>");
		out.print("<form action='LoginResponse'>");
		out.print("Enter Username : <input type='text' name='uname'>");
		out.print("<br/><br/>");
		out.print("Enter Password : <input type='text' name='upass'>");
		out.print("<br/><br/>");
		out.print("Enter Email : <input type='text' name='email'>");
		out.print("<br/><br/>");
		out.print("Enter Contact : <input type='number' name='contact'>");
		out.print("<br/><br/>");
		out.print("<button type='submit'>Login</button>");
		out.print("</form>");
		out.print("</center>");
		out.print("<body>");
		out.print("<html>");
	   
		
		
		
	    
	}

}
