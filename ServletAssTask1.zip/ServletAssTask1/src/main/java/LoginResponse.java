

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class LoginResponse
 */
@WebServlet("/LoginResponse")
public class LoginResponse extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	      response.setContentType("text/html");
	      String name=request.getParameter("uname");
	      String email=request.getParameter("email");
	      String password=request.getParameter("upass");
	      String contact=request.getParameter("contact");
	      
	      PrintWriter out=response.getWriter();
	      
	      out.print("<h2>Welcome , " + name+ "</h2>");
	      out.print("<h3>Email :"+email+"</h3>");
	      out.print("<h3>Contact :"+contact+"</h3");
	}

}
