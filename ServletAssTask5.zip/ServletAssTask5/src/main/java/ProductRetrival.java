

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Servlet implementation class ProductRetrival
 */
@WebServlet("/ProductRetrival")
public class ProductRetrival extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String id=request.getParameter("id");
		String name=request.getParameter("name");
		String price=request.getParameter("price");
		String quantity=request.getParameter("quantity");
		
		/*
		 * int p_id=Integer.parseInt(id); double p_price=Double.parseDouble(price); int
		 * p_quant=Integer.parseInt(quantity);
		 */
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/productsdb","root","01082005");
			/*
			 * PreparedStatement
			 * stmt=con.prepareStatement("Insert into productinfo values(?,?,?,?)");
			 * stmt.setString(1, id); stmt.setString(2, name); stmt.setString(3, price);
			 * stmt.setString(4, quantity);
			 * 
			 * int count=stmt.executeUpdate();
			 */
			PreparedStatement stmt1=con.prepareStatement("Select * from productinfo");
			ResultSet rs=stmt1.executeQuery();
			
			out.print("<html>");
			out.print("<body>");
			
			
	
		
			
				out.print("<table>");
				
						 out.print("<tbody>");
				 
				 out.print("<tr>"
				 		+ "<th>PRODUCT ID</th>"
				 		+ "<th>PRODUCT NAME</th>"
				 		+ "<th>PRODUCT PRICE</th>"
				 		+ "<th>PRODUCT QUANTITY</th>"
				 		+ "</tr>"
				 		);
				 
				 
				 
				                                     
				while(rs.next()) {
				
				 int id1=rs.getInt("id");
				 
				
				 String name1=rs.getString("name");
				 
				 double price1=rs.getDouble("price");
				 
				 int quantity1=rs.getInt("quantity");
				 
					/*
					 * out.print("<tr>"); out.print("<td>"+id1+"</td>");
					 * out.print("<td>"+name1+"</td>"); out.print("<td>"+price1+"</td>");
					 * out.print("<td>"+quantity1+"</td>"); out.print("</tr>");
					 */
			    
			    out.print("<tr>"
			    		+ "<td>"+id1+"</td>"
			    		+ "<td>"+name1+"</td>"
			    		+ "<td>"+price1+"</td>"
			    		+ "<td>"+quantity1+"</td>"
			    		+ "</tr>");

			    
				 
				
				 
			}
				 out.print("</tbody>");
				out.print("</table>");
			
			out.print("</body>");
			out.print("</html>");
			
			
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
