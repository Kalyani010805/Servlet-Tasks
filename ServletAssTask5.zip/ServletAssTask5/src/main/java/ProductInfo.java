

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class ProductInfo
 */
@WebServlet("/ProductInfo")
public class ProductInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		out.print("<html>");
		out.print("<body>");
		
		out.print("<center>");
		out.print("<h1>Product Registration Module</h1>");
		out.print("<hr/>");
		out.print("<form action='ProductRetrival'>");
		out.print("Enter product id : <input type='number' name='id'>");
		out.print("<br/><br/>");
		out.print("Enter product name : <input type='text' name='name'>");
		out.print("<br/><br/>");
		out.print("Enter Product price : <input type ='number' name='price'>");
		out.print("<br/><br/>");
		out.print("Enter product quantity : <input type='number' name='quantity'>");
		out.print("<br/><br/>");
		out.print("<button type='submit'>Submit</button>");
		
		
		
		out.print("</form>");
		out.print("</center>");
		out.print("</body>");
		out.print("</html>");
		
	}

}
